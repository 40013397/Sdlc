

![Valgrind](https://github.com/Dimanth/stepin-104929/workflows/Valgrind/badge.svg)

![Unit testing](https://github.com/Dimanth/stepin-104929/workflows/Unit%20testing/badge.svg)

![C/C++ CI](https://github.com/Dimanth/stepin-104929/workflows/C/C++%20CI/badge.svg)

![cppcheck-action](https://github.com/Dimanth/stepin-104929/workflows/cppcheck-action/badge.svg)

[![Codacy Badge](https://app.codacy.com/project/badge/Grade/a485ae3625ff45c3a5ebf80c9df99a0a)](https://www.codacy.com/gh/Dimanth/stepin-104929/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Dimanth/stepin-104929&amp;utm_campaign=Badge_Grade)
