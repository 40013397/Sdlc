@mainpage Intern and employee record system Application by Dimanth G S
@subpage intern.h
